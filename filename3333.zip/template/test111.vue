zgj-test.vm当前时间 : 2022-05-17 16:10:02






    [1, 2, 3, 4]



$date.format("yyyy-MM-dd HH:mm:ss",$now)
2022-05-17 16:10:02

$number.integer($myNumber)