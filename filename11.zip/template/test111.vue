zgj-test.vm当前时间 : 2022-05-17 16:08:29






    [1, 2, 3, 4]



$date.format("yyyy-MM-dd HH:mm:ss",$now)
2022-05-17 16:08:29

$number.integer($myNumber)